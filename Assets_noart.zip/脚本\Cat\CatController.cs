using UnityEngine;
using CatLife.Core;

namespace CatLife.Cat
{
    /// <summary>
    /// 猫咪行为控制
    /// 负责播放动画、响应状态变化、执行随机小动作
    /// </summary>
    public class CatController : MonoBehaviour
    {
        [Header("猫咪模型")]
        [SerializeField] private GameObject catModel;
        [SerializeField] private Animator catAnimator;

        [Header("动画配置")]
        [SerializeField] private string idleAnimName = "Idle";
        [SerializeField] private string walkAnimName = "Walk";
        [SerializeField] private string restAnimName = "Rest";
        [SerializeField] private string celebrateAnimName = "Celebrate";
        [SerializeField] private string approachAnimName = "Approach";

        [Header("随机动作")]
        [SerializeField] private bool enableRandomActions = true;
        [SerializeField] private float randomActionIntervalMin = 3f;
        [SerializeField] private float randomActionIntervalMax = 8f;

        [Header("移动配置")]
        [SerializeField] private float moveSpeed = 2f;
        [SerializeField] private float turnSpeed = 180f;

        private StateMachine stateMachine;
        private bool isActing = false;

        // 随机动作参数
        private float nextActionTime = 0f;
        private string[] randomTriggers = { "Blink", "LookAround", "Stretch", "TailWag" };

        private void Awake()
        {
            // 查找场景中的 StateMachine
            stateMachine = FindFirstObjectByType<CatLife.Core.StateMachine>();
        }

        private void OnEnable()
        {
            if (stateMachine != null)
            {
                stateMachine.OnEnterState += HandleStateEnter;
                stateMachine.OnExitState += HandleStateExit;
            }
        }

        private void OnDisable()
        {
            if (stateMachine != null)
            {
                stateMachine.OnEnterState -= HandleStateEnter;
                stateMachine.OnExitState -= HandleStateExit;
            }
        }

        private void Start()
        {
            // 初始化随机动作计时
            ResetNextActionTime();
        }

        private void Update()
        {
            // 随机小动作（仅在 Normal 状态）
            if (enableRandomActions && stateMachine != null && stateMachine.IsState(CatState.Normal))
            {
                TryRandomAction();
            }
        }

        #region 状态响应

        private void HandleStateEnter(CatState state)
        {
            Debug.Log($"[CatController] 进入状态: {state}");
            switch (state)
            {
                case CatState.Normal:
                    PlayIdle();
                    break;
                case CatState.Transition:
                    PlayApproach();
                    break;
                case CatState.Focus:
                    PlayRest();
                    break;
                case CatState.Reward:
                    PlayCelebrate();
                    break;
            }
        }

        private void HandleStateExit(CatState state)
        {
            // 停止当前动作
            if (catAnimator != null)
            {
                // 可以在这里做过渡动画
            }
        }

        #endregion

        #region 动画播放

        /// <summary>
        /// 播放待机动画（循环）
        /// </summary>
        public void PlayIdle()
        {
            PlayAnimation(idleAnimName, 0, true);
        }

        /// <summary>
        /// 播放走近动画（从 Normal 到 Focus 的过渡）
        /// </summary>
        public void PlayApproach()
        {
            PlayAnimation(approachAnimName, 0, true);
        }

        /// <summary>
        /// 播放休息动画（专注状态，循环）
        /// </summary>
        public void PlayRest()
        {
            PlayAnimation(restAnimName, 0, true);
        }

        /// <summary>
        /// 播放庆祝动画（一次性）
        /// </summary>
        public void PlayCelebrate()
        {
            PlayAnimation(celebrateAnimName, 1, false);
        }

        /// <summary>
        /// 播放走路动画
        /// </summary>
        public void PlayWalk()
        {
            PlayAnimation(walkAnimName, 0, true);
        }

        /// <summary>
        /// 停止所有动画
        /// </summary>
        public void StopAnimation()
        {
            if (catAnimator != null)
            {
                catAnimator.speed = 0f;
            }
        }

        /// <summary>
        /// 播放指定动画
        /// </summary>
        /// <param name="animName">动画名称（触发器）</param>
        /// <param name="layer">动画层级</param>
        /// <param name="loop">是否循环</param>
        private void PlayAnimation(string animName, int layer = 0, bool loop = false)
        {
            if (catAnimator == null) return;

            // 优先使用触发器（如果 Animator Controller 配置了触发器参数）
            if (!string.IsNullOrEmpty(animName))
            {
                // 尝试设置为整型来选择动画状态
                catAnimator.SetInteger("State", GetStateIndex(animName));
            }

            catAnimator.speed = loop ? 1f : 1f;
        }

        /// <summary>
        /// 将动画名称转换为状态索引
        /// </summary>
        private int GetStateIndex(string animName)
        {
            if (animName == idleAnimName) return 0;
            if (animName == walkAnimName) return 1;
            if (animName == restAnimName) return 2;
            if (animName == celebrateAnimName) return 3;
            if (animName == approachAnimName) return 4;
            return 0;
        }

        #endregion

        #region 随机动作

        /// <summary>
        /// 尝试执行随机动作
        /// </summary>
        private void TryRandomAction()
        {
            if (Time.time >= nextActionTime && !isActing)
            {
                StartCoroutine(RandomActionCoroutine());
            }
        }

        private System.Collections.IEnumerator RandomActionCoroutine()
        {
            isActing = true;

            // 随机选择动作
            int actionIndex = Random.Range(0, randomTriggers.Length);
            string triggerName = randomTriggers[actionIndex];

            Debug.Log($"[CatController] 执行随机动作: {triggerName}");

            // 播放随机动作
            if (catAnimator != null)
            {
                catAnimator.SetTrigger(triggerName);
            }

            // 等待一小段时间
            yield return new WaitForSeconds(Random.Range(1f, 3f));

            // 恢复到待机
            PlayIdle();
            ResetNextActionTime();
            isActing = false;
        }

        private void ResetNextActionTime()
        {
            nextActionTime = Time.time + Random.Range(randomActionIntervalMin, randomActionIntervalMax);
        }

        #endregion

        #region 公共方法

        /// <summary>
        /// 获取猫咪模型 Transform（供其他脚本使用）
        /// </summary>
        public Transform GetCatTransform()
        {
            return catModel != null ? catModel.transform : transform;
        }

        /// <summary>
        /// 设置猫咪位置
        /// </summary>
        public void SetPosition(Vector3 position)
        {
            if (catModel != null)
                catModel.transform.position = position;
            else
                transform.position = position;
        }

        /// <summary>
        /// 看向指定方向
        /// </summary>
        public void LookAt(Vector3 direction)
        {
            if (catModel != null)
            {
                catModel.transform.rotation = Quaternion.LookRotation(direction);
            }
        }

        #endregion
    }
}